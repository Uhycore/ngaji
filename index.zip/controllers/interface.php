<?php
interface userControllerInterface
{
    public function listUsers(); 
    public function addUser(); 
    public function editById();
    public function updateUser();
    public function deleteUser();
}
